import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Queue;
import java.util.Scanner;

public class BaseballElimination {
    private final int n;
    private final String[] teams;
    private final Map<String, Integer> idByTeam;
    private final int[] wins;
    private final int[] losses;
    private final int[] remaining;
    private final int[][] games;

    public BaseballElimination(String filename) {
        try (Scanner scanner = new Scanner(new File(filename))) {
            n = scanner.nextInt();
            teams = new String[n];
            wins = new int[n];
            losses = new int[n];
            remaining = new int[n];
            games = new int[n][n];
            idByTeam = new HashMap<>();

            for (int i = 0; i < n; i++) {
                teams[i] = scanner.next();
                idByTeam.put(teams[i], i);
                wins[i] = scanner.nextInt();
                losses[i] = scanner.nextInt();
                remaining[i] = scanner.nextInt();
                for (int j = 0; j < n; j++) {
                    games[i][j] = scanner.nextInt();
                }
            }
        } catch (FileNotFoundException e) {
            throw new IllegalArgumentException("Cannot open file: " + filename, e);
        }
    }

    public int numberOfTeams() {
        return n;
    }

    public Iterable<String> teams() {
        return Collections.unmodifiableList(Arrays.asList(teams));
    }

    public int wins(String team) {
        return wins[indexOf(team)];
    }

    public int losses(String team) {
        return losses[indexOf(team)];
    }

    public int remaining(String team) {
        return remaining[indexOf(team)];
    }

    public int against(String team1, String team2) {
        return games[indexOf(team1)][indexOf(team2)];
    }

    public boolean isEliminated(String team) {
        return certificateOfElimination(team) != null;
    }

    public Iterable<String> certificateOfElimination(String team) {
        return certificateOfElimination(team, FlowAlgorithm.DINIC);
    }

    public Iterable<String> certificateOfElimination(String team, FlowAlgorithm algorithm) {
        int x = indexOf(team);
        int maxWins = wins[x] + remaining[x];

        for (int i = 0; i < n; i++) {
            if (i != x && wins[i] > maxWins) {
                return Collections.singletonList(teams[i]);
            }
        }

        FlowBuild build = buildNetwork(x, algorithm);
        int maxFlow = build.network.maxFlow(build.source, build.sink);
        if (maxFlow == build.totalGameCapacity) {
            return null;
        }

        boolean[] inSourceSide = build.network.minCutFromSource(build.source);
        List<String> certificate = new ArrayList<>();
        for (int i = 0; i < n; i++) {
            Integer vertex = build.teamVertexByTeamId.get(i);
            if (vertex != null && inSourceSide[vertex]) {
                certificate.add(teams[i]);
            }
        }
        return certificate;
    }

    private int indexOf(String team) {
        Integer id = idByTeam.get(team);
        if (id == null) {
            throw new IllegalArgumentException("Unknown team: " + team);
        }
        return id;
    }

    private FlowBuild buildNetwork(int x, FlowAlgorithm algorithm) {
        int otherTeams = n - 1;
        int gameVertices = otherTeams * (otherTeams - 1) / 2;
        int source = 0;
        int firstGameVertex = 1;
        int firstTeamVertex = firstGameVertex + gameVertices;
        int sink = firstTeamVertex + otherTeams;

        MaxFlowNetwork network = algorithm.createNetwork(sink + 1);
        Map<Integer, Integer> teamVertexByTeamId = new HashMap<>();
        int teamVertex = firstTeamVertex;
        for (int i = 0; i < n; i++) {
            if (i == x) {
                continue;
            }
            teamVertexByTeamId.put(i, teamVertex++);
        }

        int totalGameCapacity = 0;
        int gameVertex = firstGameVertex;
        final int infinity = 1_000_000_000;
        for (int i = 0; i < n; i++) {
            if (i == x) {
                continue;
            }
            for (int j = i + 1; j < n; j++) {
                if (j == x) {
                    continue;
                }
                int capacity = games[i][j];
                totalGameCapacity += capacity;
                network.addEdge(source, gameVertex, capacity);
                network.addEdge(gameVertex, teamVertexByTeamId.get(i), infinity);
                network.addEdge(gameVertex, teamVertexByTeamId.get(j), infinity);
                gameVertex++;
            }
        }

        int maxWins = wins[x] + remaining[x];
        for (int i = 0; i < n; i++) {
            if (i == x) {
                continue;
            }
            network.addEdge(teamVertexByTeamId.get(i), sink, maxWins - wins[i]);
        }

        return new FlowBuild(network, source, sink, totalGameCapacity, teamVertexByTeamId);
    }

    public static void main(String[] args) {
        if (args.length < 1 || args.length > 2) {
            System.err.println("Usage: java BaseballElimination <input-file> [ford|edmonds|dinic|all]");
            return;
        }

        BaseballElimination division = new BaseballElimination(args[0]);
        if (args.length == 1) {
            printResult(division, FlowAlgorithm.DINIC, false);
            return;
        }

        String option = args[1].toLowerCase();
        if ("all".equals(option)) {
            for (FlowAlgorithm algorithm : FlowAlgorithm.values()) {
                printResult(division, algorithm, true);
            }
        } else {
            printResult(division, FlowAlgorithm.fromOption(option), false);
        }
    }

    private static void printResult(BaseballElimination division, FlowAlgorithm algorithm, boolean showHeader) {
        long start = System.nanoTime();
        List<String> lines = new ArrayList<>();
        for (String team : division.teams()) {
            Iterable<String> certificate = division.certificateOfElimination(team, algorithm);
            lines.add(formatResult(team, certificate));
        }
        long elapsed = System.nanoTime() - start;

        if (showHeader) {
            System.out.println("=== " + algorithm.displayName + " ===");
        }
        for (String line : lines) {
            System.out.println(line);
        }
        if (showHeader) {
            System.out.printf("Time: %.3f ms%n%n", elapsed / 1_000_000.0);
        }
    }

    private static String formatResult(String team, Iterable<String> certificate) {
        if (certificate == null) {
            return team + " is not eliminated";
        }

        StringBuilder builder = new StringBuilder();
        builder.append(team).append(" is eliminated by the subset R = { ");
        for (String eliminatingTeam : certificate) {
            builder.append(eliminatingTeam).append(' ');
        }
        builder.append('}');
        return builder.toString();
    }

    public enum FlowAlgorithm {
        FORD_FULKERSON("Ford-Fulkerson") {
            @Override
            MaxFlowNetwork createNetwork(int vertices) {
                return new FordFulkerson(vertices);
            }
        },
        EDMONDS_KARP("Edmonds-Karp") {
            @Override
            MaxFlowNetwork createNetwork(int vertices) {
                return new EdmondsKarp(vertices);
            }
        },
        DINIC("Dinic") {
            @Override
            MaxFlowNetwork createNetwork(int vertices) {
                return new Dinic(vertices);
            }
        };

        private final String displayName;

        FlowAlgorithm(String displayName) {
            this.displayName = displayName;
        }

        abstract MaxFlowNetwork createNetwork(int vertices);

        private static FlowAlgorithm fromOption(String option) {
            if ("ford".equals(option) || "ford-fulkerson".equals(option)) {
                return FORD_FULKERSON;
            }
            if ("edmonds".equals(option) || "edmonds-karp".equals(option)) {
                return EDMONDS_KARP;
            }
            if ("dinic".equals(option)) {
                return DINIC;
            }
            throw new IllegalArgumentException("Unknown algorithm: " + option);
        }
    }

    private static final class FlowBuild {
        private final MaxFlowNetwork network;
        private final int source;
        private final int sink;
        private final int totalGameCapacity;
        private final Map<Integer, Integer> teamVertexByTeamId;

        private FlowBuild(MaxFlowNetwork network, int source, int sink, int totalGameCapacity,
                          Map<Integer, Integer> teamVertexByTeamId) {
            this.network = network;
            this.source = source;
            this.sink = sink;
            this.totalGameCapacity = totalGameCapacity;
            this.teamVertexByTeamId = teamVertexByTeamId;
        }
    }

    private abstract static class MaxFlowNetwork {
        protected final List<Edge>[] graph;

        @SuppressWarnings("unchecked")
        private MaxFlowNetwork(int vertices) {
            graph = new ArrayList[vertices];
            for (int i = 0; i < vertices; i++) {
                graph[i] = new ArrayList<>();
            }
        }

        protected void addEdge(int from, int to, int capacity) {
            if (capacity < 0) {
                capacity = 0;
            }
            Edge forward = new Edge(to, graph[to].size(), capacity);
            Edge backward = new Edge(from, graph[from].size(), 0);
            graph[from].add(forward);
            graph[to].add(backward);
        }

        protected abstract int maxFlow(int source, int sink);

        protected boolean[] minCutFromSource(int source) {
            boolean[] visited = new boolean[graph.length];
            Queue<Integer> queue = new ArrayDeque<>();
            visited[source] = true;
            queue.add(source);
            while (!queue.isEmpty()) {
                int vertex = queue.remove();
                for (Edge edge : graph[vertex]) {
                    if (edge.capacity > 0 && !visited[edge.to]) {
                        visited[edge.to] = true;
                        queue.add(edge.to);
                    }
                }
            }
            return visited;
        }
    }

    private static final class FordFulkerson extends MaxFlowNetwork {
        private FordFulkerson(int vertices) {
            super(vertices);
        }

        @Override
        protected int maxFlow(int source, int sink) {
            int flow = 0;
            int pushed;
            while ((pushed = dfs(source, sink, Integer.MAX_VALUE, new boolean[graph.length])) > 0) {
                flow += pushed;
            }
            return flow;
        }

        private int dfs(int vertex, int sink, int flow, boolean[] visited) {
            if (vertex == sink) {
                return flow;
            }
            visited[vertex] = true;
            for (Edge edge : graph[vertex]) {
                if (edge.capacity <= 0 || visited[edge.to]) {
                    continue;
                }
                int pushed = dfs(edge.to, sink, Math.min(flow, edge.capacity), visited);
                if (pushed > 0) {
                    edge.capacity -= pushed;
                    graph[edge.to].get(edge.reverse).capacity += pushed;
                    return pushed;
                }
            }
            return 0;
        }
    }

    private static final class EdmondsKarp extends MaxFlowNetwork {
        private EdmondsKarp(int vertices) {
            super(vertices);
        }

        @Override
        protected int maxFlow(int source, int sink) {
            int flow = 0;
            Edge[] parentEdge = new Edge[graph.length];
            int[] parentVertex = new int[graph.length];

            while (findShortestAugmentingPath(source, sink, parentVertex, parentEdge)) {
                int bottleNeck = Integer.MAX_VALUE;
                for (int vertex = sink; vertex != source; vertex = parentVertex[vertex]) {
                    bottleNeck = Math.min(bottleNeck, parentEdge[vertex].capacity);
                }
                for (int vertex = sink; vertex != source; vertex = parentVertex[vertex]) {
                    Edge edge = parentEdge[vertex];
                    edge.capacity -= bottleNeck;
                    graph[edge.to].get(edge.reverse).capacity += bottleNeck;
                }
                flow += bottleNeck;
            }
            return flow;
        }

        private boolean findShortestAugmentingPath(int source, int sink, int[] parentVertex, Edge[] parentEdge) {
            Arrays.fill(parentVertex, -1);
            Arrays.fill(parentEdge, null);
            Queue<Integer> queue = new ArrayDeque<>();
            parentVertex[source] = source;
            queue.add(source);

            while (!queue.isEmpty() && parentVertex[sink] < 0) {
                int vertex = queue.remove();
                for (Edge edge : graph[vertex]) {
                    if (edge.capacity > 0 && parentVertex[edge.to] < 0) {
                        parentVertex[edge.to] = vertex;
                        parentEdge[edge.to] = edge;
                        queue.add(edge.to);
                        if (edge.to == sink) {
                            break;
                        }
                    }
                }
            }
            return parentVertex[sink] >= 0;
        }
    }

    private static final class Dinic extends MaxFlowNetwork {
        private final int[] level;
        private final int[] next;

        private Dinic(int vertices) {
            super(vertices);
            level = new int[vertices];
            next = new int[vertices];
        }

        @Override
        protected int maxFlow(int source, int sink) {
            int flow = 0;
            while (buildLevels(source, sink)) {
                Arrays.fill(next, 0);
                int pushed;
                while ((pushed = push(source, sink, Integer.MAX_VALUE)) > 0) {
                    flow += pushed;
                }
            }
            return flow;
        }

        private boolean buildLevels(int source, int sink) {
            Arrays.fill(level, -1);
            Queue<Integer> queue = new ArrayDeque<>();
            level[source] = 0;
            queue.add(source);
            while (!queue.isEmpty()) {
                int vertex = queue.remove();
                for (Edge edge : graph[vertex]) {
                    if (edge.capacity > 0 && level[edge.to] < 0) {
                        level[edge.to] = level[vertex] + 1;
                        queue.add(edge.to);
                    }
                }
            }
            return level[sink] >= 0;
        }

        private int push(int vertex, int sink, int flow) {
            if (vertex == sink) {
                return flow;
            }
            for (; next[vertex] < graph[vertex].size(); next[vertex]++) {
                Edge edge = graph[vertex].get(next[vertex]);
                if (edge.capacity <= 0 || level[edge.to] != level[vertex] + 1) {
                    continue;
                }
                int pushed = push(edge.to, sink, Math.min(flow, edge.capacity));
                if (pushed > 0) {
                    edge.capacity -= pushed;
                    graph[edge.to].get(edge.reverse).capacity += pushed;
                    return pushed;
                }
            }
            return 0;
        }
    }

    private static final class Edge {
        private final int to;
        private final int reverse;
        private int capacity;

        private Edge(int to, int reverse, int capacity) {
            this.to = to;
            this.reverse = reverse;
            this.capacity = capacity;
        }
    }
}

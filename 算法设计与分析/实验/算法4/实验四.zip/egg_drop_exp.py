import random
import time
import math
import matplotlib.pyplot as plt
from functools import lru_cache
import sys

# 增加递归深度限制，支持大规模测试
sys.setrecursionlimit(100000)

# 配置matplotlib中文字体
plt.rcParams['font.sans-serif'] = ['SimHei', 'Microsoft YaHei', 'DejaVu Sans']
plt.rcParams['axes.unicode_minus'] = False


# =========================
# 1. 蛮力递归法
# =========================
def egg_drop_bruteforce(e, f):
    if f == 0 or f == 1:
        return f
    if e == 1:
        return f

    ans = float("inf")

    for x in range(1, f + 1):
        broken = egg_drop_bruteforce(e - 1, x - 1)
        not_broken = egg_drop_bruteforce(e, f - x)
        worst = 1 + max(broken, not_broken)
        ans = min(ans, worst)

    return ans


# =========================
# 2. 记忆化搜索
# =========================
@lru_cache(None)
def egg_drop_memo(e, f):
    if f == 0 or f == 1:
        return f
    if e == 1:
        return f

    ans = float("inf")

    for x in range(1, f + 1):
        broken = egg_drop_memo(e - 1, x - 1)
        not_broken = egg_drop_memo(e, f - x)
        worst = 1 + max(broken, not_broken)
        ans = min(ans, worst)

    return ans


# =========================
# 3. 二分优化
# =========================
@lru_cache(None)
def egg_drop_binary(e, f):
    if f == 0 or f == 1:
        return f
    if e == 1:
        return f

    left, right = 1, f
    ans = float("inf")

    while left <= right:
        mid = (left + right) // 2

        broken = egg_drop_binary(e - 1, mid - 1)
        not_broken = egg_drop_binary(e, f - mid)

        worst = 1 + max(broken, not_broken)
        ans = min(ans, worst)

        if broken < not_broken:
            left = mid + 1
        else:
            right = mid - 1

    return ans


# =========================
# 4. 优化状态法
# dp[m][e] 表示 m 次实验、e 个鸡蛋最多能确定多少层
# =========================
def egg_drop_optimized_state(e, f):
    if f == 0:
        return 0

    dp = [0] * (e + 1)
    moves = 0

    while dp[e] < f:
        moves += 1
        for eggs in range(e, 0, -1):
            dp[eggs] = dp[eggs] + dp[eggs - 1] + 1

    return moves


# =========================
# 小数据正确性测试
# =========================
def correctness_test(test_times=10):
    print("="*70)
    print("小数据正确性测试（四种算法对比）")
    print("="*70)

    passed = True
    for i in range(test_times):
        e = random.randint(1, 3)
        f = random.randint(1, 10)

        brute = egg_drop_bruteforce(e, f)

        egg_drop_memo.cache_clear()
        memo = egg_drop_memo(e, f)

        egg_drop_binary.cache_clear()
        binary = egg_drop_binary(e, f)

        opt = egg_drop_optimized_state(e, f)

        print(f"测试{i + 1:2d}: e={e:2d}, f={f:2d} | "
              f"蛮力={brute:3d}, 记忆化={memo:3d}, "
              f"二分={binary:3d}, 优化状态={opt:3d}")

        if not (brute == memo == binary == opt):
            print("  ❌ 结果不一致，测试失败！")
            passed = False

    if passed:
        print("\n✅ 所有小数据测试通过，说明算法结果正确")
    else:
        print("\n❌ 存在测试结果不一致")

    return passed


# =========================
# 运行时间测试辅助函数
# =========================
def measure_time(func, e, f):
    start = time.perf_counter()
    result = func(e, f)
    end = time.perf_counter()
    return result, end - start


def run_algorithm_test(algo_name, algo_func, test_cases, fixed_param_type,
                       clear_cache=False, theory_func=None):
    """
    通用算法测试函数

    参数:
        algo_name: 算法名称
        algo_func: 算法函数
        test_cases: 测试用例列表 [(param1, param2), ...]
        fixed_param_type: 'eggs' 或 'floors'，表示固定的参数类型
        clear_cache: 是否需要清除缓存
        theory_func: 理论复杂度计算函数 lambda e, f, result: value
    """
    print(f"\n{'='*70}")
    print(f"{algo_name}")
    print(f"{'='*70}")

    results = []
    labels = []
    actual_times = []
    theory_values = []

    for e, f in test_cases:
        if fixed_param_type == 'floors':
            labels.append(f"f={f}")
        else:
            labels.append(f"e={e}")

        # 清除缓存（如果需要）
        if clear_cache:
            algo_func.cache_clear()

        # 测量运行时间
        try:
            result, elapsed = measure_time(algo_func, e, f)
            print(f"e={e:4d}, f={f:10d} | 结果={result:6d} | 时间={elapsed:.6f}s")

            # 计算理论值
            if theory_func:
                theory = theory_func(e, f, result)
            else:
                theory = 0

            results.append(result)
            actual_times.append(elapsed)
            theory_values.append(theory)
        except Exception as ex:
            print(f"e={e:4d}, f={f:10d} | 错误: {str(ex)}")
            results.append(None)
            actual_times.append(None)
            theory_values.append(None)

    return {
        "algo_name": algo_name,
        "fixed_param_type": fixed_param_type,
        "labels": labels,
        "results": results,
        "actual_times": actual_times,
        "theory_values": theory_values,
    }


# =========================
# 效率测试主函数
# =========================
def efficiency_tests():
    """执行所有算法的效率测试（只保留固定鸡蛋数，楼层增加的测试）"""

    all_results = []

    # A. 蛮力递归法（只做小规模测试）
    print("\n\n" + "="*70)
    print("A. 蛮力递归法 bruteForce")
    print("="*70)

    # A1. 固定鸡蛋数 e=2，改变楼层数
    test_cases_a1 = [(2, f) for f in [2, 4, 6, 8, 10, 12, 14, 16, 18, 20]]
    result_a1 = run_algorithm_test(
        "A. 蛮力递归 - 固定鸡蛋数 e=2",
        egg_drop_bruteforce,
        test_cases_a1,
        'floors',
        clear_cache=False,
        theory_func=lambda e, f, r: pow(2, f)
    )
    all_results.append(result_a1)

    # B. 记忆化搜索
    print("\n\n" + "="*70)
    print("B. 记忆化搜索 memoization")
    print("="*70)

    # B1. 固定鸡蛋数 e=3，改变楼层数
    test_cases_b1 = [(3, f) for f in [100, 200, 400, 800, 1200, 1600, 2000, 2400, 2800, 3200]]
    result_b1 = run_algorithm_test(
        "B. 记忆化搜索 - 固定鸡蛋数 e=3",
        egg_drop_memo,
        test_cases_b1,
        'floors',
        clear_cache=True,
        theory_func=lambda e, f, r: e * f * f
    )
    all_results.append(result_b1)

    # C. 二分优化
    print("\n\n" + "="*70)
    print("C. 二分优化 binaryOptimization")
    print("="*70)

    # C1. 固定鸡蛋数 e=3，改变楼层数
    test_cases_c1 = [(3, f) for f in [1000, 2000, 5000, 10000, 20000, 30000, 40000, 50000]]
    result_c1 = run_algorithm_test(
        "C. 二分优化 - 固定鸡蛋数 e=3",
        egg_drop_binary,
        test_cases_c1,
        'floors',
        clear_cache=True,
        theory_func=lambda e, f, r: e * f * math.log2(f + 1)
    )
    all_results.append(result_c1)

    # D. 优化状态法
    print("\n\n" + "="*70)
    print("D. 优化状态法 optimizedState")
    print("="*70)

    # D1. 固定鸡蛋数 e=3，改变楼层数
    test_cases_d1 = [(3, f) for f in [10000, 50000, 100000, 500000, 1000000, 5000000, 10000000]]
    result_d1 = run_algorithm_test(
        "D. 优化状态法 - 固定鸡蛋数 e=3",
        egg_drop_optimized_state,
        test_cases_d1,
        'floors',
        clear_cache=False,
        theory_func=None
    )
    all_results.append(result_d1)

    return all_results


# =========================
# 绘制对比图
# =========================
def draw_algorithm_charts(all_results):
    """为每个算法的测试绘制实际时间与理论复杂度对比图"""

    chart_count = 0

    for result in all_results:
        algo_name = result["algo_name"]
        labels = result["labels"]
        actual_times = result["actual_times"]
        theory_values = result["theory_values"]
        fixed_type = result["fixed_param_type"]

        # 过滤掉None值
        valid_data = [(i, t, th) for i, (t, th) in enumerate(zip(actual_times, theory_values))
                      if t is not None and th is not None]

        if not valid_data:
            print(f"⚠️  {algo_name}: 没有有效数据，跳过绘图")
            continue

        valid_indices = [item[0] for item in valid_data]
        valid_times = [item[1] for item in valid_data]
        valid_theories = [item[2] for item in valid_data]

        # 判断是否有有效的理论值（非零）
        has_theory = any(th > 0 for th in valid_theories)

        # 归一化理论值到实际时间的量级
        max_time = max(valid_times)
        
        if has_theory:
            max_theory = max(valid_theories)
            if max_theory > 0:
                normalized_theory = [t / max_theory * max_time for t in valid_theories]
            else:
                normalized_theory = []
        else:
            normalized_theory = []

        # 绘图
        plt.figure(figsize=(12, 6))

        x_positions = range(len(labels))
        valid_x = [list(x_positions).index(idx) for idx in valid_indices]

        plt.plot(valid_x, valid_times, marker='o', linewidth=2, markersize=6,
                label='实际运行时间', color='#2196F3')
        
        if has_theory and normalized_theory:
            plt.plot(valid_x, normalized_theory, marker='s', linewidth=2, markersize=6,
                    linestyle='--', label='理论复杂度趋势', color='#FF5722')

        # 设置x轴标签
        valid_labels = [labels[idx] for idx in valid_indices]
        plt.xticks(range(len(valid_labels)), valid_labels, rotation=30, fontsize=9)

        plt.xlabel('楼层数', fontsize=11)
        plt.ylabel('运行时间（秒）', fontsize=11)
        plt.title(f'{algo_name}\n实际效率 vs 理论复杂度', fontsize=13, fontweight='bold')
        plt.legend(loc='upper left', fontsize=10)
        plt.grid(True, alpha=0.3, linestyle=':')
        plt.tight_layout()

        # 生成文件名
        chart_count += 1
        filename = f"chart_{chart_count:02d}.png"
        plt.savefig(filename, dpi=300, bbox_inches='tight')
        plt.show()
        print(f"✅ 已保存: {filename}")

    print(f"\n共生成 {chart_count} 张图表")


# =========================
# 主函数
# =========================
if __name__ == "__main__":
    random.seed(42)

    print("\n" + "="*70)
    print("扔鸡蛋问题算法实验")
    print("="*70)

    # 1. 小数据正确性测试
    correctness_test(test_times=10)

    # 2. 效率测试（只保留固定鸡蛋数，楼层增加的测试）
    all_results = efficiency_tests()

    # 3. 绘制图表
    print("\n\n" + "="*70)
    print("开始绘制图表")
    print("="*70)
    draw_algorithm_charts(all_results)

    print("\n" + "="*70)
    print("实验完成！")
    print("="*70)
    print("\n生成的图表文件：")
    print("  chart_01.png - 蛮力递归法（e=2）")
    print("  chart_02.png - 记忆化搜索（e=3）")
    print("  chart_03.png - 二分优化（e=3）")
    print("  chart_04.png - 优化状态法（e=3）")
